import React from 'react'

const Board = () => {
  return (
    <div>
      게시판
    </div>
  )
}

export default Board
