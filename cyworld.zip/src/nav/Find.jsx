import React from 'react'

const Find = () => {
  return (
    <div className='find'>
      qlalfqjsghckwrl
    </div>
  )
}

export default Find
